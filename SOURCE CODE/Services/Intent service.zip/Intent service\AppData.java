package com.webgrity.backgroundservice;

public class AppData {
    public static boolean isAppInForeground = false;
}
