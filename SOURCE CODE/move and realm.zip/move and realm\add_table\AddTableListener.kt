package net.app.mvvmsampleapp.floor.design.add_table

import android.content.Context

interface AddTableListener {
    fun addButtonClick(id: String)
}